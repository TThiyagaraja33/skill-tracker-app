package com.cts.skilltracker.retrieve.model;

import lombok.Data;

@Data
public class UserInput {

	private String userName;
	private String password;
}
